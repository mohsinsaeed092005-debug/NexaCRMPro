import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

type Tone =
  | "neutral"
  | "signal"
  | "emerald"
  | "amber"
  | "rose"
  | "sky";

const toneClasses: Record<Tone, string> = {
  neutral: "bg-ink-950/[0.05] text-text-secondary",
  signal: "bg-signal-soft text-signal-dark",
  emerald: "bg-emerald-soft text-emerald",
  amber: "bg-amber-soft text-amber",
  rose: "bg-rose-soft text-rose",
  sky: "bg-sky-soft text-sky",
};

export function Badge({
  tone = "neutral",
  dot = false,
  className,
  children,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: Tone; dot?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[12px] font-medium leading-none",
        toneClasses[tone],
        className
      )}
      {...props}
    >
      {dot && (
        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current" />
      )}
      {children}
    </span>
  );
}

export const statusTone: Record<string, Tone> = {
  Active: "emerald",
  Onboarding: "sky",
  "At risk": "amber",
  Churned: "rose",
  New: "sky",
  Contacted: "signal",
  Qualified: "amber",
  Proposal: "signal",
  Won: "emerald",
  Lost: "rose",
  High: "rose",
  Medium: "amber",
  Low: "sky",
};
