import Link from "next/link";
import { TrendingUp, Users, Radar } from "lucide-react";

const proof = [
  { label: "Active clients tracked", value: "186", icon: Users },
  { label: "Avg. lead response time", value: "4 min", icon: Radar },
  { label: "Conversion lift", value: "+29%", icon: TrendingUp },
];

export function AuthBrandPanel() {
  return (
    <div className="relative hidden overflow-hidden bg-ink-950 lg:flex lg:flex-col lg:justify-between lg:px-12 lg:py-10 xl:px-16">
      {/* signature: concentric signal rings, echoing the live-pulse motif from the product */}
      <div className="pointer-events-none absolute -right-24 top-1/2 h-[560px] w-[560px] -translate-y-1/2">
        {[0, 1, 2, 3].map((i) => (
          <span
            key={i}
            className="absolute inset-0 rounded-full border border-white/[0.06]"
            style={{ inset: `${i * 62}px` }}
          />
        ))}
        <span className="absolute inset-[186px] rounded-full bg-signal/20 blur-2xl" />
        <span className="absolute inset-[210px] flex items-center justify-center rounded-full bg-signal">
          <span className="signal-dot h-2.5 w-2.5 rounded-full bg-white text-white" />
          <span className="absolute h-2.5 w-2.5 rounded-full bg-white" />
        </span>
      </div>

      <Link href="/dashboard" className="relative z-10 flex items-center gap-2.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-signal">
          <span className="h-1.5 w-1.5 rounded-full bg-white" />
        </span>
        <span className="font-[family-name:var(--font-display)] text-[17px] font-bold tracking-tight text-white">
          Nexa<span className="text-signal">CRM</span>
        </span>
      </Link>

      <div className="relative z-10 max-w-md">
        <p className="mb-3 text-[13px] font-semibold uppercase tracking-wider text-signal">
          Built for sales teams
        </p>
        <h2 className="font-[family-name:var(--font-display)] text-[34px] font-bold leading-[1.15] tracking-tight text-white xl:text-[38px]">
          Know every deal before it moves.
        </h2>
        <p className="mt-4 text-[15px] leading-relaxed text-text-on-ink-muted">
          NexaCRM keeps your clients, leads, and tasks in one clear view —
          so nothing important is ever a surprise.
        </p>
      </div>

      <div className="relative z-10 grid grid-cols-3 gap-4 border-t border-line-on-ink pt-6">
        {proof.map((p) => {
          const Icon = p.icon;
          return (
            <div key={p.label}>
              <Icon size={15} className="mb-2 text-signal" />
              <p className="font-[family-name:var(--font-mono)] text-[19px] font-semibold text-white">
                {p.value}
              </p>
              <p className="mt-0.5 text-[11.5px] leading-snug text-text-on-ink-muted">
                {p.label}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
