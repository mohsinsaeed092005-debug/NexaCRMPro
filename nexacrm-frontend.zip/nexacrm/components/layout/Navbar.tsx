"use client";

import { Menu, Search, Bell, Plus, ChevronDown } from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { currentUser } from "@/lib/data";

export function Navbar({ onMenuClick }: { onMenuClick?: () => void }) {
  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center gap-3 border-b border-line bg-surface/85 px-4 backdrop-blur-md sm:px-6">
      <button
        onClick={onMenuClick}
        aria-label="Open navigation"
        className="rounded-lg p-2 text-text-secondary hover:bg-canvas lg:hidden"
      >
        <Menu size={19} />
      </button>

      <div className="relative hidden max-w-md flex-1 sm:block">
        <Search
          size={16}
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary"
        />
        <input
          type="text"
          placeholder="Search clients, leads, tasks…"
          className="h-9 w-full rounded-lg border border-line bg-canvas pl-9 pr-3 text-[13.5px] text-text-primary placeholder:text-text-tertiary outline-none transition-colors focus:border-signal focus:bg-surface focus:ring-2 focus:ring-signal/15"
        />
      </div>

      <div className="flex flex-1 justify-end items-center gap-2 sm:gap-3">
        <button
          aria-label="Search"
          className="rounded-lg p-2 text-text-secondary hover:bg-canvas sm:hidden"
        >
          <Search size={18} />
        </button>

        <Button variant="secondary" size="sm" className="hidden sm:inline-flex">
          <Plus size={15} />
          Quick add
        </Button>

        <button
          aria-label="Notifications"
          className="relative rounded-lg p-2 text-text-secondary hover:bg-canvas"
        >
          <Bell size={18} />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-rose ring-2 ring-surface" />
        </button>

        <div className="mx-1 hidden h-6 w-px bg-line sm:block" />

        <button className="flex items-center gap-2 rounded-lg py-1 pl-1 pr-1.5 hover:bg-canvas sm:pr-2">
          <Avatar initials={currentUser.initials} size="sm" />
          <span className="hidden text-left sm:block">
            <span className="block text-[13px] font-medium leading-tight text-text-primary">
              {currentUser.name}
            </span>
          </span>
          <ChevronDown size={14} className="hidden text-text-tertiary sm:block" />
        </button>
      </div>
    </header>
  );
}
